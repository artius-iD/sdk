//
//  artiusid_sdk_ios.h
//  artiusid-sdk-ios
//
//  Created by Nelson Soler on 2/11/25.
//

#import <Foundation/Foundation.h>

//! Project version number for artiusid_sdk_ios.
FOUNDATION_EXPORT double artiusid_sdk_iosVersionNumber;

//! Project version string for artiusid_sdk_ios.
FOUNDATION_EXPORT const unsigned char artiusid_sdk_iosVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <artiusid_sdk_ios/PublicHeader.h>


